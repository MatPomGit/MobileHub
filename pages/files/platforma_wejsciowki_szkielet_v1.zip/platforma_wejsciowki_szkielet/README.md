# Platforma wejściówek — szkielet

Szkielet aplikacji dydaktycznej obejmującej:
- materiały kursowe,
- wejściówki z limitem czasu,
- autosave odpowiedzi,
- minimalną telemetrię bez zapisu treści klawiszy,
- panel wyników studenta,
- panel prowadzącego,
- PostgreSQL i Prisma,
- kontenery Docker.

## Stos
- Frontend: Next.js + React + TypeScript
- Backend: NestJS + TypeScript
- Baza: PostgreSQL
- ORM: Prisma
- Cache: Redis
- Uruchomienie lokalne: Docker Compose

## Uruchomienie

1. Skopiuj konfigurację:

```bash
cp .env.example .env
```

2. Uruchom bazę i Redis:

```bash
docker compose up -d postgres redis
```

3. Zainstaluj zależności:

```bash
npm install
```

4. Wygeneruj klienta Prisma i wykonaj migrację:

```bash
npm run prisma:generate
npm run prisma:migrate
```

5. Uruchom aplikacje:

```bash
npm run dev
```

Frontend: http://localhost:3000  
Backend: http://localhost:4000/api

## Ważne

To jest szkielet demonstracyjny, nie gotowy system produkcyjny. Przed wdrożeniem należy uzupełnić:
- uwierzytelnianie OIDC/SSO,
- autoryzację per kurs i rola,
- ochronę CSRF, rate limiting i nagłówki bezpieczeństwa,
- politykę retencji,
- DPIA i dokumentację RODO,
- testy integracyjne, E2E, bezpieczeństwa i dostępności,
- szyfrowanie numeru indeksu,
- kopie zapasowe i monitoring.
