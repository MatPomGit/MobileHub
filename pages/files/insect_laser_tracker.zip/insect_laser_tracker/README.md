# Insect Laser Tracker

Prototyp badawczy systemu wykrywającego niewielki, szybko poruszający się obiekt,
przewidującego jego położenie i kierującego w to miejsce bezpieczny wskaźnik laserowy.

## Architektura

1. Kamera przekazuje obraz do programu `tracker.py`.
2. MOG2 wyznacza maskę ruchu.
3. Kontury są filtrowane według rozmiaru i ciągłości ruchu.
4. Filtr Kalmana estymuje położenie i prędkość.
5. Położenie jest ekstrapolowane o czas `lead_time_ms`.
6. Komenda `AIM,pan,tilt` trafia do mikrokontrolera.
7. Komenda `LASER,czas_ms` jest wysyłana tylko po stabilnym śledzeniu.
8. Firmware wyłącza laser po czasie impulsu, zaniku interlocku albo komunikacji.

## Uruchomienie

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python tracker.py --config config.yaml
```

W systemie Windows:

```powershell
.venv\Scripts\activate
python tracker.py --config config.yaml
```

Sterowanie sprzętem jest domyślnie wyłączone:

```yaml
control:
  enabled: false
```

Po sprawdzeniu pracy w trybie podglądu należy ustawić właściwy port i dopiero potem
zmienić `enabled` na `true`.

## Oznaczenia na obrazie

- żółty punkt — pomiar,
- niebieski okrąg — położenie filtrowane,
- czerwony krzyż — położenie przewidywane,
- zielony prostokąt — dozwolona programowo strefa wskazywania.

## Kalibracja

Mapowanie liniowe jest wystarczające tylko do demonstratora z osiami pan–tilt.
Dla lustra galwanometrycznego należy zarejestrować pary:

```text
(x obrazu, y obrazu) -> (napięcie X galvo, napięcie Y galvo)
```

i dopasować transformację wielomianową lub homografię. Sterownik galvo powinien
otrzymywać sygnał z przetwornika DAC, a nie bezpośrednio z pinów PWM.

## Bezpieczeństwo

- Stosować kompletny, certyfikowany moduł klasy 1 lub odpowiednio obudowany produkt klasy 2.
- Pracować wyłącznie w zamkniętej strefie z pochłaniaczem wiązki.
- Zastosować fizyczny E-STOP i sprzętowy interlock odcinający zasilanie lasera.
- Nie polegać wyłącznie na warunkach programowych.
- Nie kierować wiązki na ludzi ani zwierzęta.
