import Link from "next/link";

export function Header({ active = "dashboard" }: { active?: string }) {
  return (
    <header className="topbar">
      <Link href="/" className="brand" style={{ textDecoration: "none" }}>
        <span className="logo" aria-hidden="true">W</span>
        <span>Wejściówki</span>
      </Link>

      <nav className="topnav" aria-label="Główna nawigacja">
        <Link className={active === "dashboard" ? "active" : ""} href="/">Pulpit</Link>
        <Link className={active === "materials" ? "active" : ""} href="/materialy">Materiały</Link>
        <Link className={active === "results" ? "active" : ""} href="/wyniki">Wyniki</Link>
        <Link className={active === "instructor" ? "active" : ""} href="/prowadzacy">Prowadzący</Link>
      </nav>

      <div className="user">
        <span>Mateusz Pomianek</span>
        <span className="logo" aria-hidden="true" style={{ width: 34, height: 34 }}>MP</span>
      </div>
    </header>
  );
}
