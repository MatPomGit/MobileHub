# Architektura

## Moduły

- `apps/web` — interfejs studenta i prowadzącego.
- `apps/api` — API transakcyjne i telemetryczne.
- `packages/database` — schemat Prisma/PostgreSQL.
- PostgreSQL — dane transakcyjne, wyniki, logi audytowe.
- Redis — sesje krótkotrwałe, TTL, rate limiting.

## Kanały danych

1. Kanał transakcyjny:
   - rozpoczęcie próby,
   - zapis odpowiedzi,
   - zakończenie próby,
   - obliczenie wyniku.

2. Kanał telemetryczny:
   - paczki zdarzeń co kilka sekund,
   - próbkowany ruch wskaźnika,
   - zmiana widoczności karty,
   - metadane klawiszy nawigacyjnych,
   - bez zapisu treści wpisywanych znaków.

## Zasady bezpieczeństwa

- klucz odpowiedzi wyłącznie po stronie serwera,
- serwerowy czas rozpoczęcia i zakończenia,
- autoryzacja per zasób,
- unikalność `attemptId + seqNo`,
- audyt operacji prowadzącego i administratora,
- krótka retencja surowej telemetrii,
- brak automatycznego orzekania o niesamodzielności.
