import { Header } from "@/components/Header";

export default function InstructorPage() {
  return (
    <div className="shell">
      <Header active="instructor" />
      <main id="main" className="container">
        <div className="section-head">
          <div><h1>Panel prowadzącego</h1><p>Zestawienie prób, wyników i podstawowej telemetrii.</p></div>
          <button className="btn">Nowa wejściówka</button>
        </div>

        <section className="metric-grid">
          <div className="card metric"><small>Aktywne kursy</small><strong>3</strong></div>
          <div className="card metric"><small>Studenci</small><strong>128</strong></div>
          <div className="card metric"><small>Próby dzisiaj</small><strong>42</strong></div>
          <div className="card metric"><small>Średni wynik</small><strong>74%</strong></div>
        </section>

        <div className="section-head"><div><h2>Ostatnie podejścia</h2></div></div>
        <div className="table-wrap">
          <table>
            <thead>
              <tr><th>Nr indeksu</th><th>Wejściówka</th><th>Start</th><th>Wynik</th><th>Ukrycia karty</th><th>Akcja</th></tr>
            </thead>
            <tbody>
              <tr><td>*****123</td><td>Podstawy obrazu</td><td>09:02</td><td>9/10</td><td>0</td><td><button className="btn secondary">Szczegóły</button></td></tr>
              <tr><td>*****914</td><td>Podstawy obrazu</td><td>09:04</td><td>7/10</td><td>2</td><td><button className="btn secondary">Szczegóły</button></td></tr>
              <tr><td>*****287</td><td>Podstawy obrazu</td><td>09:06</td><td>8/10</td><td>1</td><td><button className="btn secondary">Szczegóły</button></td></tr>
            </tbody>
          </table>
        </div>

        <div className="privacy-note" style={{ marginTop: 20 }}>
          Telemetria nie jest automatycznym dowodem niesamodzielności. Każda decyzja akademicka wymaga oceny prowadzącego i uwzględnienia kontekstu.
        </div>
      </main>
    </div>
  );
}
