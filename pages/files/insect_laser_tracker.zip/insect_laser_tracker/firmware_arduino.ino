\
/*
  Sterownik demonstratora: 2 serwa + bezpieczny wskaźnik laserowy.

  WAŻNE:
  - pin INTERLOCK_PIN musi pochodzić z fizycznego łańcucha bezpieczeństwa,
  - stan LOW oznacza brak zgody na laser,
  - po utracie komunikacji laser jest wyłączany,
  - układ nie zastępuje sprzętowego odcięcia zasilania lasera.
*/

#include <Servo.h>

constexpr uint8_t PAN_PIN = 9;
constexpr uint8_t TILT_PIN = 10;
constexpr uint8_t LASER_EN_PIN = 7;
constexpr uint8_t INTERLOCK_PIN = 4;

constexpr uint32_t WATCHDOG_MS = 150;
constexpr float PAN_MIN = 15.0f;
constexpr float PAN_MAX = 165.0f;
constexpr float TILT_MIN = 20.0f;
constexpr float TILT_MAX = 160.0f;

Servo panServo;
Servo tiltServo;

uint32_t lastCommandMs = 0;
uint32_t laserOffAtMs = 0;

void safeOff() {
  digitalWrite(LASER_EN_PIN, LOW);
  laserOffAtMs = 0;
}

bool interlockOk() {
  return digitalRead(INTERLOCK_PIN) == HIGH;
}

void setup() {
  pinMode(LASER_EN_PIN, OUTPUT);
  pinMode(INTERLOCK_PIN, INPUT_PULLUP);
  safeOff();

  panServo.attach(PAN_PIN);
  tiltServo.attach(TILT_PIN);
  panServo.write(90);
  tiltServo.write(90);

  Serial.begin(115200);
  Serial.setTimeout(10);
  lastCommandMs = millis();
}

void processAim(const String &line) {
  int first = line.indexOf(',');
  int second = line.indexOf(',', first + 1);
  if (first < 0 || second < 0) return;

  float pan = line.substring(first + 1, second).toFloat();
  float tilt = line.substring(second + 1).toFloat();

  pan = constrain(pan, PAN_MIN, PAN_MAX);
  tilt = constrain(tilt, TILT_MIN, TILT_MAX);

  panServo.write((int)round(pan));
  tiltServo.write((int)round(tilt));
}

void processLaser(const String &line) {
  int comma = line.indexOf(',');
  if (comma < 0 || !interlockOk()) {
    safeOff();
    return;
  }

  int durationMs = constrain(line.substring(comma + 1).toInt(), 1, 100);
  digitalWrite(LASER_EN_PIN, HIGH);
  laserOffAtMs = millis() + durationMs;
}

void processLine(String line) {
  line.trim();
  lastCommandMs = millis();

  if (line.startsWith("AIM,")) {
    processAim(line);
  } else if (line.startsWith("LASER,")) {
    processLaser(line);
  } else if (line == "SAFE_OFF") {
    safeOff();
  }
}

void loop() {
  if (!interlockOk()) {
    safeOff();
  }

  if (laserOffAtMs != 0 && (int32_t)(millis() - laserOffAtMs) >= 0) {
    safeOff();
  }

  if (millis() - lastCommandMs > WATCHDOG_MS) {
    safeOff();
  }

  if (Serial.available()) {
    String line = Serial.readStringUntil('\n');
    processLine(line);
  }
}
