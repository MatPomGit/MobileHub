\
#!/usr/bin/env python3
"""
Insect Laser Tracker — prototyp badawczy.

Laser pełni wyłącznie rolę wskaźnika celu. Kod wymaga:
- zamkniętej strefy roboczej,
- lasera klasy 1 albo certyfikowanego produktu klasy 2,
- sprzętowego interlocku,
- fizycznego E-STOP,
- pochłaniacza wiązki.

Domyślnie sterowanie sprzętem jest wyłączone w config.yaml.
"""

from __future__ import annotations

import argparse
import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import cv2
import numpy as np
import yaml

try:
    import serial
except ImportError:
    serial = None


@dataclass
class Detection:
    x: float
    y: float
    area: float
    timestamp: float


class ConstantVelocityKalman:
    """Filtr Kalmana dla stanu [x, y, vx, vy]."""

    def __init__(self, process_noise: float, measurement_noise: float) -> None:
        self.kf = cv2.KalmanFilter(4, 2)
        self.kf.measurementMatrix = np.array(
            [[1, 0, 0, 0], [0, 1, 0, 0]], dtype=np.float32
        )
        self.kf.transitionMatrix = np.eye(4, dtype=np.float32)
        self.kf.processNoiseCov = np.eye(4, dtype=np.float32) * process_noise
        self.kf.measurementNoiseCov = np.eye(2, dtype=np.float32) * measurement_noise
        self.kf.errorCovPost = np.eye(4, dtype=np.float32) * 10.0
        self.initialized = False
        self.last_time: Optional[float] = None

    def reset(self) -> None:
        self.initialized = False
        self.last_time = None

    def update(self, detection: Detection) -> np.ndarray:
        now = detection.timestamp

        if not self.initialized:
            self.kf.statePost = np.array(
                [[detection.x], [detection.y], [0], [0]], dtype=np.float32
            )
            self.initialized = True
            self.last_time = now
            return self.kf.statePost.copy()

        dt = max(0.0005, min(now - (self.last_time or now), 0.1))
        self.last_time = now
        self.kf.transitionMatrix = np.array(
            [[1, 0, dt, 0],
             [0, 1, 0, dt],
             [0, 0, 1, 0],
             [0, 0, 0, 1]],
            dtype=np.float32,
        )
        self.kf.predict()
        measurement = np.array([[detection.x], [detection.y]], dtype=np.float32)
        return self.kf.correct(measurement)

    def predict_ahead(self, lead_s: float) -> tuple[float, float]:
        state = self.kf.statePost.reshape(-1)
        return float(state[0] + state[2] * lead_s), float(state[1] + state[3] * lead_s)


class InsectDetector:
    def __init__(self, cfg: dict) -> None:
        self.cfg = cfg
        self.bg = cv2.createBackgroundSubtractorMOG2(
            history=int(cfg["history"]),
            varThreshold=float(cfg["var_threshold"]),
            detectShadows=False,
        )
        self.kernel = np.ones((3, 3), np.uint8)

    def detect(
        self,
        frame: np.ndarray,
        previous: Optional[tuple[float, float]],
        timestamp: float,
    ) -> tuple[Optional[Detection], np.ndarray]:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        gray = cv2.GaussianBlur(gray, (3, 3), 0)

        mask = self.bg.apply(gray, learningRate=float(self.cfg["learning_rate"]))
        _, mask = cv2.threshold(
            mask, int(self.cfg["threshold"]), 255, cv2.THRESH_BINARY
        )
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, self.kernel)

        contours, _ = cv2.findContours(
            mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
        )

        candidates: list[Detection] = []
        min_area = float(self.cfg["min_area_px"])
        max_area = float(self.cfg["max_area_px"])

        for contour in contours:
            area = cv2.contourArea(contour)
            if not (min_area <= area <= max_area):
                continue

            moments = cv2.moments(contour)
            if abs(moments["m00"]) < 1e-9:
                continue

            x = moments["m10"] / moments["m00"]
            y = moments["m01"] / moments["m00"]
            candidates.append(Detection(x=x, y=y, area=area, timestamp=timestamp))

        if not candidates:
            return None, mask

        if previous is None:
            selected = min(candidates, key=lambda c: c.area)
        else:
            px, py = previous
            selected = min(candidates, key=lambda c: (c.x - px) ** 2 + (c.y - py) ** 2)
            jump = math.hypot(selected.x - px, selected.y - py)
            if jump > float(self.cfg["max_jump_px"]):
                return None, mask

        return selected, mask


class ImageToActuator:
    """Mapowanie punktu obrazu na kąty serw lub komendy galvo."""

    def __init__(self, width: int, height: int, control: dict, calibration: dict) -> None:
        self.w = width
        self.h = height
        self.c = control
        self.cal = calibration

    def map(self, x: float, y: float) -> tuple[float, float]:
        nx = np.clip(x / max(self.w - 1, 1), 0.0, 1.0)
        ny = np.clip(y / max(self.h - 1, 1), 0.0, 1.0)

        if self.cal.get("invert_x", False):
            nx = 1.0 - nx
        if self.cal.get("invert_y", False):
            ny = 1.0 - ny

        pan = self.c["pan_min_deg"] + nx * (
            self.c["pan_max_deg"] - self.c["pan_min_deg"]
        )
        tilt = self.c["tilt_min_deg"] + ny * (
            self.c["tilt_max_deg"] - self.c["tilt_min_deg"]
        )
        return float(pan), float(tilt)


class HardwareController:
    def __init__(self, cfg: dict) -> None:
        self.cfg = cfg
        self.enabled = bool(cfg.get("enabled", False))
        self.port = None

        if self.enabled:
            if serial is None:
                raise RuntimeError("Brak pyserial. Uruchom: pip install pyserial")
            self.port = serial.Serial(
                cfg["serial_port"],
                int(cfg["baudrate"]),
                timeout=0.02,
                write_timeout=0.02,
            )
            time.sleep(1.5)
            self.send_safe_off()

    def _write(self, message: str) -> None:
        if self.enabled and self.port is not None:
            self.port.write((message.strip() + "\n").encode("ascii"))

    def aim(self, pan: float, tilt: float) -> None:
        self._write(f"AIM,{pan:.2f},{tilt:.2f}")

    def laser_pulse(self, duration_ms: int) -> None:
        self._write(f"LASER,{int(duration_ms)}")

    def send_safe_off(self) -> None:
        self._write("SAFE_OFF")

    def close(self) -> None:
        try:
            self.send_safe_off()
        finally:
            if self.port is not None:
                self.port.close()


def inside_safe_zone(x: float, y: float, width: int, height: int, margin: int) -> bool:
    return margin <= x < width - margin and margin <= y < height - margin


def open_camera(cfg: dict) -> cv2.VideoCapture:
    cap = cv2.VideoCapture(int(cfg["index"]))
    if not cap.isOpened():
        raise RuntimeError("Nie można otworzyć kamery.")

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(cfg["width"]))
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(cfg["height"]))
    cap.set(cv2.CAP_PROP_FPS, int(cfg["fps"]))

    exposure = float(cfg.get("exposure", -1))
    if exposure >= 0:
        cap.set(cv2.CAP_PROP_EXPOSURE, exposure)

    cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
    return cap


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument("--no-gui", action="store_true")
    args = parser.parse_args()

    with Path(args.config).open("r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)

    cap = open_camera(cfg["camera"])
    ok, frame = cap.read()
    if not ok:
        raise RuntimeError("Brak pierwszej klatki z kamery.")

    height, width = frame.shape[:2]
    detector = InsectDetector(cfg["detection"])
    kalman = ConstantVelocityKalman(
        float(cfg["prediction"]["process_noise"]),
        float(cfg["prediction"]["measurement_noise"]),
    )
    mapper = ImageToActuator(width, height, cfg["control"], cfg["calibration"])
    hardware = HardwareController(cfg["control"])

    previous: Optional[tuple[float, float]] = None
    consecutive = 0
    last_seen = 0.0
    last_laser = 0.0
    lead_s = float(cfg["prediction"]["lead_time_ms"]) / 1000.0

    fps_time = time.perf_counter()
    fps_counter = 0
    displayed_fps = 0.0

    try:
        while True:
            ok, frame = cap.read()
            now = time.perf_counter()
            if not ok:
                hardware.send_safe_off()
                break

            detection, mask = detector.detect(frame, previous, now)

            if detection is None:
                consecutive = 0
                if (now - last_seen) * 1000.0 > float(cfg["detection"]["lost_timeout_ms"]):
                    previous = None
                    kalman.reset()
                    hardware.send_safe_off()
            else:
                last_seen = now
                consecutive += 1
                state = kalman.update(detection)
                filtered_x, filtered_y = float(state[0]), float(state[1])
                previous = (filtered_x, filtered_y)
                pred_x, pred_y = kalman.predict_ahead(lead_s)

                safe = inside_safe_zone(
                    pred_x,
                    pred_y,
                    width,
                    height,
                    int(cfg["control"]["safe_margin_px"]),
                )

                pan, tilt = mapper.map(pred_x, pred_y)
                if safe:
                    hardware.aim(pan, tilt)

                error_px = math.hypot(pred_x - filtered_x, pred_y - filtered_y)
                stable = consecutive >= int(cfg["detection"]["min_track_frames"])
                cooldown_ok = (
                    now - last_laser
                ) * 1000.0 >= float(cfg["control"]["laser_cooldown_ms"])
                error_ok = error_px <= float(cfg["control"]["max_tracking_error_px"])

                # Laser aktywowany wyłącznie, gdy śledzenie jest stabilne i punkt jest
                # wewnątrz programowej strefy bezpieczeństwa. Sprzętowy interlock
                # pozostaje obowiązkowy.
                if safe and stable and cooldown_ok and error_ok:
                    hardware.laser_pulse(int(cfg["control"]["laser_pulse_ms"]))
                    last_laser = now

                if not args.no_gui:
                    cv2.circle(frame, (int(detection.x), int(detection.y)), 5, (0, 255, 255), 1)
                    cv2.circle(frame, (int(filtered_x), int(filtered_y)), 7, (255, 0, 0), 1)
                    cv2.drawMarker(
                        frame,
                        (int(pred_x), int(pred_y)),
                        (0, 0, 255),
                        cv2.MARKER_CROSS,
                        16,
                        2,
                    )
                    cv2.line(
                        frame,
                        (int(filtered_x), int(filtered_y)),
                        (int(pred_x), int(pred_y)),
                        (0, 255, 0),
                        1,
                    )

            fps_counter += 1
            elapsed = now - fps_time
            if elapsed >= 0.5:
                displayed_fps = fps_counter / elapsed
                fps_counter = 0
                fps_time = now

            if not args.no_gui:
                margin = int(cfg["control"]["safe_margin_px"])
                cv2.rectangle(
                    frame,
                    (margin, margin),
                    (width - margin, height - margin),
                    (0, 180, 0),
                    1,
                )
                cv2.putText(
                    frame,
                    f"FPS: {displayed_fps:.1f}  track: {consecutive}",
                    (15, 30),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.7,
                    (255, 255, 255),
                    2,
                )
                cv2.imshow("Insect tracker", frame)
                cv2.imshow("Foreground mask", mask)
                key = cv2.waitKey(1) & 0xFF
                if key in (27, ord("q")):
                    break

    finally:
        hardware.close()
        cap.release()
        cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
