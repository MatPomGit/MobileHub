import Link from "next/link";
import { Header } from "@/components/Header";

const quizzes = [
  { title: "Podstawy analizy obrazu", course: "Analiza i obróbka obrazów", time: "10 min", status: "Dostępna", cls: "success" },
  { title: "Modele klasyfikacyjne", course: "Uczenie maszynowe", time: "12 min", status: "Jutro 08:00", cls: "warning" },
  { title: "Wprowadzenie do ROS 2", course: "Robotyka afektywna", time: "8 min", status: "Zakończona", cls: "" }
];

export default function Dashboard() {
  return (
    <div className="shell">
      <Header />
      <main id="main" className="container">
        <section className="hero">
          <div>
            <h1>Materiały i wejściówki w jednym miejscu</h1>
            <p>Przeglądaj zasoby kursów, rozwiązuj krótkie sprawdziany i kontroluj historię swoich wyników.</p>
          </div>
          <div className="hero-stat">
            <span>Średni wynik</span>
            <strong>82%</strong>
            <small>z ostatnich 6 prób</small>
          </div>
        </section>

        <div className="section-head">
          <div>
            <h2>Najbliższe wejściówki</h2>
            <p>Terminy i aktualny status podejść.</p>
          </div>
        </div>

        <section className="grid" aria-label="Lista wejściówek">
          {quizzes.map((quiz, index) => (
            <article className="card" key={quiz.title}>
              <span className={`badge ${quiz.cls}`}>{quiz.status}</span>
              <h3 style={{ marginTop: 14 }}>{quiz.title}</h3>
              <p>{quiz.course}</p>
              <div className="meta">
                <span className="badge">Czas: {quiz.time}</span>
                <span className="badge">1 podejście</span>
              </div>
              {index === 0 ? (
                <Link className="btn" href="/quiz/demo">Rozpocznij</Link>
              ) : (
                <button className="btn secondary" disabled={index === 1}>
                  {index === 1 ? "Jeszcze niedostępna" : "Zobacz wynik"}
                </button>
              )}
            </article>
          ))}
        </section>

        <div className="section-head">
          <div>
            <h2>Ostatnie materiały</h2>
            <p>Nowo opublikowane zasoby dydaktyczne.</p>
          </div>
          <Link href="/materialy">Pokaż wszystkie</Link>
        </div>

        <section className="grid">
          {["Histogram i kontrast", "Filtracja przestrzenna", "Morfologia matematyczna"].map((title, i) => (
            <article className="card" key={title}>
              <span className="badge">Tydzień {i + 1}</span>
              <h3 style={{ marginTop: 14 }}>{title}</h3>
              <p>Materiał wykładowy, przykłady oraz zestaw ćwiczeń.</p>
              <button className="btn secondary">Otwórz materiał</button>
            </article>
          ))}
        </section>
      </main>
    </div>
  );
}
