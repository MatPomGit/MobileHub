# Skrócona checklista wdrożeniowa

- [ ] OIDC/SSO i mapowanie ról.
- [ ] Autoryzacja per kurs, próba i student.
- [ ] Szyfrowanie numerów indeksów.
- [ ] Klucz odpowiedzi wyłącznie po stronie serwera.
- [ ] Serwerowy timer i atomowe zakończenie próby.
- [ ] Idempotentny autosave.
- [ ] Rate limiting API i telemetrii.
- [ ] CSP, HSTS, ochrona CSRF i bezpieczne cookies.
- [ ] Polityka retencji danych.
- [ ] DPIA, klauzula informacyjna i rejestr czynności.
- [ ] Testy jednostkowe, integracyjne i E2E.
- [ ] Testy WCAG 2.2 AA.
- [ ] Backup i test odtworzeniowy.
- [ ] Monitoring i alerty.
- [ ] Procedura obsługi incydentów.
