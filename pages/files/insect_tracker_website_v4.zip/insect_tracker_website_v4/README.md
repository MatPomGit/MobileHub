# InsectTrack website v4

Wersja rozszerzona o:
- listę komponentów z odnośnikami,
- instrukcje podłączenia,
- schematy połączeń,
- przykłady kodu Python, OpenCV, PCA9685, UART i firmware,
- opis sterowania galvo przez DAC.

Uruchomienie:

```bash
cd insect_tracker_website_v4
python -m http.server 8000
```

Następnie otwórz http://localhost:8000.
